# AERO COMMAND — Supabase-backed executive dashboard

This is an English-language, single-page starter application adapted from `EGYPTAIR_Dashboard(1).html`.

## Supabase project
- Project: `EGYPTAIR-Operations-Dashboard`
- Project ref: `xuvkbyniszzetkebqfmo`
- Region: Frankfurt (`eu-central-1`)
- URL: `https://xuvkbyniszzetkebqfmo.supabase.co`
- Browser key: Supabase publishable key (safe for browser use when RLS is enabled)

## Included
- Email/password sign-up and sign-in via Supabase Auth
- Owner-scoped PostgreSQL tables protected by RLS
- Department directory, work-order summary, risk register, decisions and budget rollups
- Add risk and decision records; update decision status
- CSV export for department financial/headcount summary
- Explicitly labelled sample-data loader, preserving the prototype's illustrative values

## Run locally
1. Serve this folder from a local web server (for example `python -m http.server 8000`).
2. Open `http://localhost:8000`.
3. Create an account using an email address you can verify.
4. If email confirmation is enabled, confirm the message and then sign in.
5. Select **Load prototype sample data** if you want to explore the dashboard with sample values.

The database migration has already been applied to the Supabase project. The application uses the Supabase JavaScript v2 CDN and the project's publishable key; it does not contain a service-role or secret key.

## Important limitations before production use
- The uploaded prototype explicitly states that its figures are simulated and are not actual EGYPTAIR data. The sample loader preserves that status and labels records `is_demo = true`.
- The prototype's operational source systems (maintenance, HR, inventory, safety, finance and decision records) have not been connected. No real airline operational records have been imported.
- This is a deployable starter, not yet a publicly hosted website. Deploy the folder to a static host (for example Vercel, Netlify or Cloudflare Pages) and configure the Supabase Auth site URL/redirect URLs for that host.
- Before production use, define organization roles/permissions, review safety-data governance, connect approved source systems, configure backups/monitoring, and conduct security and operational acceptance testing.
